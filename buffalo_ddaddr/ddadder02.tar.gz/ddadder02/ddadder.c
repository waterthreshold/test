// ddadder (c) Eko 2007
// v0.1 initial release
// v0.2 new models added, typos fixed

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>


int FileSize( const char * szFileName )
{
  struct stat fileStat;
  int err = stat( szFileName, &fileStat );
  if (0 != err) return 0;
  return fileStat.st_size;
}


int main(int argc, char *argv[])
{


int size;
char buf, outfilename[512];
int counter = 0;
int i = 0;
char fsize[7];
char *head;

	if (argv[1] == NULL || argv[2] == NULL || argc > 3)  //print usage info
		{
			printf ("\n ddadder v0.2 - add Buffalo header to input file (c) Eko\n\n");
			printf (" usage:\n\n");
			printf ("ddadder inputfile model\n\n\n");
			printf (" inputfile: generic dd-wrt build\n\n");
			printf (" supported model strings:\n\n");
			printf ("  wla-g54\n");
			printf ("  wla-g54c\n");
			printf ("  wla2-g54c\n");
			printf ("  wla2-g54l\n");
			printf ("  wbr-g54\n");
			printf ("  wbr2-g54\n");
			printf ("  wbr2-g54s\n");
			printf ("  wli-tx4-g54hp\n");
			printf ("  wli3-tx1-g54\n");
			printf ("  wzr-rs-g54\n");
			return;
		}

		printf ("\nSelected model: %s\n", argv[2]);

	FILE *infile = fopen (argv[1], "rb");

  		if (infile == NULL)
			{
    	  printf ("file N/A - please select valid input file!\n");
		  return;
			}

			if (fgetc (infile) == 'H'
				&& fgetc (infile) == 'D'
				&& fgetc (infile) == 'R'
				&& fgetc (infile) == '0')
					{
				    rewind (infile); //file OK
					}
				else
					{
					printf ("Input file is invalid, please use generic.bin file\n");
					fclose (infile);
					return;
					}




	if (!strcmp (argv[2], "wla-g54"))
		head = "WLA-G54 2.05 1.02";
	else if (!strcmp (argv[2], "wla-g54c"))
		head = "WLA-B11C 2.20 1.05";
	else if (!strcmp (argv[2], "wla2-g54c"))
		head = "WLA2-G54C 2.23 1.05";
	else if (!strcmp (argv[2], "wla2-g54l"))
		head = "WLA2-G54L 2.24 1.00";
	else if (!strcmp (argv[2], "wbr-g54"))
		head = "WBR-B11 2.20 1.16";
	else if (!strcmp (argv[2], "wbr2-g54"))
		head = "WBR2-G54 2.30 6.03";
	else if (!strcmp (argv[2], "wbr2-g54s"))
		head = "WBR2-G54S 2.30 6.10";
	else if (!strcmp (argv[2], "wli-tx4-g54hp"))
		head = "WLI-TX4-G54HP 2.50 2.03";
	else if (!strcmp (argv[2], "wli3-tx1-g54"))
		head = "WLI3-TX1-G54 2.30 1.07";
	else if (!strcmp (argv[2], "wzr-rs-g54"))
		head = "WZR-RS-G54 2.32 1.01";
	else
		{
		printf ("unknown model %s - please select valid model!\n", argv[2]);
		return;
		}



size = FileSize(argv[1]);
sprintf (fsize, "%d", size);
printf ("input file size = %s\n", fsize);

	sprintf (outfilename, "dd-buffalo-%s.bin", argv[2]);
	FILE *outfile = fopen (outfilename, "wb");



	fputs (head, outfile);
	fputs ("\x0A", outfile);
	fputs ("filelen=", outfile);
	for (i=0; i < 7 ; i++)
		fputc (fsize[i], outfile);
	fputs ("\x0A", outfile);


  		while (counter < size)
    {
		buf = fgetc (infile);

		fputc (buf, outfile);

		counter ++;

	}

	printf ("File %s written with added Buffalo header", outfilename);

fclose (infile);
fclose (outfile);

}

